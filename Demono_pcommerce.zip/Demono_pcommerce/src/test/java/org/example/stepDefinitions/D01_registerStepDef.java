package org.example.stepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import org.example.Pages.RegisterElements;
import org.junit.Assert;
import org.openqa.selenium.support.ui.Select;

import org.openqa.selenium.By;

public class D01_registerStepDef {

    RegisterElements reg =new RegisterElements();

    @Given("user go to register page")
    public void goToRegister(){

        reg.registerLink().click();
    }

    @When("user select gender type")
    public void userSelectGenderType() {
        reg.genderRadioBtn().click();

    }

    @And("user enter first name")
    public void userEnterFirstName() {

        reg.firstName().sendKeys("automation");
    }

    @And("user Enter last name")
    public void userEnterLastName() {

        reg.lastName().sendKeys("tester");
    }


    @And("user enter date of birth")
    public void userEnterDateOfBirth() {
        reg.day().selectByValue("3");
        reg.month().selectByValue("5");
        reg.year().selectByValue("1996");
    }

    @And("user enter email field")
    public void userEnterEmailField() {

        reg.email().sendKeys("teeoopst@example.com");
    }

    @And("user fills Password fields")
    public void userFillsPasswordFields() {
        reg.firstPassword().sendKeys("P@ssw0rd");
        reg.confirmPassword().sendKeys("P@ssw0rd");
    }

    @And("user clicks on register button")
    public void userClicksOnRegisterButton() {

        reg.registerButton().click();
    }

    @And("success message is displayed")
    public void successMessageIsDisplayed() {

        String expected ="Your registration completed";
        String actual = reg.registermessage().getText();
        Assert.assertEquals(true,actual.contains(expected));
        System.out.println("sucess");
    }
}
